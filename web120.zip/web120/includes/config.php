<?php
//config.php

$siteKey = "6LeRfpAUAAAAAAvra_-oPbdjGI-zQ-F3cLBxj0R1";
$secretKey = "6LeRfpAUAAAAAEgOxMKIhjDNalCGOftf8Zy-xyO-";

//echo basename($_SERVER['PHP_SELF']);
define('THIS_PAGE' , basename($_SERVER['PHP_SELF']));

//helps prevent date errors
date_default_timezone_set('America/Los_Angeles');

//reCapthca credentials here 

//echo THIS_PAGE; 

//die;

$title = THIS_PAGE; 

switch(THIS_PAGE){

    case 'index.php':
        $title = 'Nicole\'s Home Page!';
        $logo = "fa-home";
     break; 

    case 'contactme.php':
        $title = 'Nicole\'s Contact Page!';
        $logo = "fa-paper-plane-o";
     break; 
} 
//place URL & labels in the array here for navigation:
$nav1['index.php'] = "Welcome";
$nav1['big/index.php'] = "Big";
$nav1['aia.php'] = "AIA";
$nav1['flowchart.php'] = "Flowchart";
$nav1['fp/index.php'] = "Final Project";
$nav1['contactme.php'] = "Contact Nicole";

/*
makeLinks function will create our dynamic nav when called.
Call like this:
echo makeLinks($nav1); #in which $nav1 is an associative array of links
*/
function makeLinks($linkArray)
{
    $myReturn = '';

    foreach($linkArray as $url => $text)
    {
        if($url == THIS_PAGE)
        {//selected page - add class reference
	    	$myReturn .= '<li><a class="selected" href="' . $url . '">' . $text . '</a></li>' . PHP_EOL;
    	}else{
	    	$myReturn .= '<li><a href="' . $url . '">' . $text . '</a></li>'  . PHP_EOL;
    	}    
    }
      
    return $myReturn;    
}






?>