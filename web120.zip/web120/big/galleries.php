

<!DOCTYPE html>
<html lang="en">
 <head>
  <title>Nicole's BIG Page!</title>
  <meta name="robots" content="noindex,nofollow" />
  <meta name="viewport" content="width=device-width" />
  <meta charset="utf-8" />
    <!--script src="https://use.fontawesome.com/6a71565c22.js"></script-->
     <!--from menumaker zip file-->
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="https://s3.amazonaws.com/menumaker/menumaker.min.js" type="text/javascript"></script>
    <script src="js/script.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="css/styles.css" />
     <!--from menumaker zip file-->
  <link rel="stylesheet" href="css/big.css" />
  <link rel="stylesheet" href="css/nav.css" />
  <link rel="stylesheet" href="css/form.css" />
 </head>
 
<body>   
<!--START WRAPPER-->
<div class="wrapper">
<header>
  <h1><a href="index.php"><i class="logo fa fa-home"></i>NICOLE FINAMORE'S WEB EXAMPLES/RESEARCH ARTICLES</a></h1>
  <nav id="cssmenu">
  <ul>
     <li><a href="../index.php"><span><i class="fa fa-fw fa-bank"></i> WEB120 Portal</span></a></li>
     <li><a href="index.php"><span><i class="fa fa-fw fa-home"></i> Home</span></a></li>
     <li><a href="flexbox.php"><span>Flexbox</span></a></li>
     <li><a href="galleries.php"><span>Galleries</span></a></li>
     <li><a href="#"><span><i class="fa fa-fw fa-chevron-down"></i> Google</span></a>
        <ul>
           <li><a href="map.php"><span>Map</span></a></li>
           <li><a href="calendar.php"><span>Calendar</span></a></li>
           <li><a href="youtube.php"><span>YouTube</span></a></li>
        </ul>
     </li>
     <li><a href="shoppingcarts.php"><span>Shopping Carts</span></a></li>
     <li><a href="siteapp.php"><span>Site vs App</span></a></li>
     <li><a href="webcam.php"><span>Web Cam</span></a></li>
  </ul>
</nav>
</header><!-- START LEFT COL--> 
    <section>
    <h2>GALLERIES</h2>
    
 <p> Galleries are used on a client’s website in order to make the site sleek, presentable, and if many photos are used, it can be used to manage photos, which can be seen in this article from Hongkiat, “If your website is image heavy, ie a portfolio or photography website etc., then there are two things that you’ll be needing the most-photo gallery plugins to help you better manage the images on your website, and image slideshows to showcase your images to the world.” (Ashutosh).  Galleries offer different design qualities to websites, and when choosing a gallery, be aware that there are hundreds to choose from. Some galleries offer really unique features for the user’s experience and ability to manipulate photos, as can be seen in this statement from Photoswipe, “Images are displayed at their highest possible size and are not limited by the width of the column or wrapper. Each image is isolated from the other content and fits the viewport vertically, so that the user can focus on it. If an image is larger than the viewport, it can be zoomed (which most galleries are unable to do).” (PhotoSwipe).  </p>
 <p> It’s nice to see that there are many HTML galleries available for designers today, and can be easily used for the non-designer who doesn’t know how to code, as can be seen in this statement from Juicebox, “Juicebox is a complete web image gallery solution. Use Juicebox to create spectacular HTML5 image galleries for your web site with no coding required. Juicebox is simple to set up and use, and includes complete browser and mobile device support.” (Juicebox). Galleries offer many design elements to enhance your website, and can give your website the extra design boost when needed. When choosing a gallery for a client, make sure the gallery best suits the client’s needs, and is easy to manage for your client. </p>
</section>
<!-- END LEFT COL -->
     
<!-- START RIGHT COL -->
 <aside>
         <h3>Citations</h3>
           <dl>
             <dt>“Spectacular HTML5 Image Galleries Made Easy”<a href="https://www.juicebox.net/ " target = "_blank">JUICEBOX.COM</a> </dt>
             <dd>JUICEBOX</dd>
         
         </dl>
         <dl>
             <dt>“Javascript Galleries No Dependencies”<a href="https://photoswipe.com/" target = "_blank">PHOTOSWIPE.COM</a></dt>
             <dd>PHOTOSWIPE</dd>
         
         </dl>
         <dl>
             <dt>"20 Responsive Image Galleries and Slideshows”<a href="https://www.hongkiat.com/blog/free-responsive-image-gallery/ " target = "_blank">HONGKIAT.COM</a></dt>
             <dd>HONGKIAT</dd>
         
         </dl> 
    
     </aside>
<!-- END RIGHT COL -->
       
 <footer>
      <p><small>&copy; 2018- 2019 by <a href="clientform.php">Contact Nicole Finamore</a>, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer" target="_blank">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank">Valid CSS</a></small></p>
    </footer>  