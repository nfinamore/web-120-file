<?php 
//* config.php file for BIG

// Here are the keys for the server: dreamhost-nicolecodes.net nicolesform
$siteKey = "6LeRfpAUAAAAAAvra_-oPbdjGI-zQ-F3cLBxj0R1";
$secretKey = "6LeRfpAUAAAAAEgOxMKIhjDNalCGOftf8Zy-xyO-";

//echo basename($_SERVER['PHP_SELF']);
define('THIS_PAGE',basename($_SERVER['PHP_SELF']));

//helps prevent date errors
date_default_timezone_set('America/Los_Angeles');

//reCapthca credentials here 

//echo THIS_PAGE; 

//die;

$title = THIS_PAGE; 

switch(THIS_PAGE){

    case 'index.php':
        $title = 'Nicole\'s BIG Page!';
        $logo = "fa-home";
     break; 

    case 'contactme.php':
        $title = 'Nicole\'s Contact Page!';
        $logo = "fa-paper-plane-o";
     break; 
} 