 <footer>
      <p><small>&copy; 2018- <?=date("Y")?> by <a href="clientform.php">Contact Nicole Finamore</a>, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer" target="_blank">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank">Valid CSS</a></small></p>
    </footer>