
<!DOCTYPE html>
<html lang="en">
 <head>
  <title>Nicole's BIG Page!</title>
  <meta name="robots" content="noindex,nofollow" />
  <meta name="viewport" content="width=device-width" />
  <meta charset="utf-8" />
    <!--script src="https://use.fontawesome.com/6a71565c22.js"></script-->
     <!--from menumaker zip file-->
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="https://s3.amazonaws.com/menumaker/menumaker.min.js" type="text/javascript"></script>
    <script src="js/script.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="css/styles.css" />
     <!--from menumaker zip file-->
  <link rel="stylesheet" href="css/big.css" />
  <link rel="stylesheet" href="css/nav.css" />
  <link rel="stylesheet" href="css/form.css" />
 </head>
 
<body>   
<!--START WRAPPER-->
<div class="wrapper">
<header>
  <h1><a href="index.php"><i class="logo fa fa-home"></i>NICOLE FINAMORE'S WEB EXAMPLES/RESEARCH ARTICLES</a></h1>
  <nav id="cssmenu">
  <ul>
     <li><a href="../index.php"><span><i class="fa fa-fw fa-bank"></i> WEB120 Portal</span></a></li>
     <li><a href="index.php"><span><i class="fa fa-fw fa-home"></i> Home</span></a></li>
     <li><a href="flexbox.php"><span>Flexbox</span></a></li>
     <li><a href="galleries.php"><span>Galleries</span></a></li>
     <li><a href="#"><span><i class="fa fa-fw fa-chevron-down"></i> Google</span></a>
        <ul>
           <li><a href="map.php"><span>Map</span></a></li>
           <li><a href="calendar.php"><span>Calendar</span></a></li>
           <li><a href="youtube.php"><span>YouTube</span></a></li>
        </ul>
     </li>
     <li><a href="shoppingcarts.php"><span>Shopping Carts</span></a></li>
     <li><a href="siteapp.php"><span>Site vs App</span></a></li>
     <li><a href="webcam.php"><span>Web Cam</span></a></li>
  </ul>
</nav>
</header><!-- START LEFT COL--> 
    <section>
    <h2>FLEXBOX</h2>
    
 <p>Flexbox is a great way for designers to organize boxes and the space around them without relying to heavily on CSS for floats and positioning. CSS for floats and positioning can work just fine but can be time consuming and limiting. The term “Flex” comes from the fact that items flex to fill additional space, and shrink to fit into smaller spaces. Flexbox allows boxes to be more flexible and makes the layout easier to work with, which can be seen in this article from Codeburst, “With Flexbox, the container has the ability to alter it’s items width and height, order, and can even determine the amount of space a particular item in the container can occupy.  Flexbox is easier to use as opposed to some limitations set on us with the traditional standards of CSS, which can be seen in this article from Mozilla,“Flexbox is a one-dimensional layout method for laying out items in rows or columns. Items flex to fill additional space and shrink to fit into smaller spaces. This article explains all the fundamentals”(Mozilla). </p>
 <p>Flexbox allows multiple column layouts, with equal sized columns, and the columns can have the same height as well, through default values given to flex items. If a client wants to use a lot of columns or boxes containing text, this is a great tool to use for your client’s needs. 
Flexbox has positive reactions from those developers who choose to use this tool, which can be seen is this article by Nemi, “Flexbox is quite powerful, and though we’ve just scratched the surface, you can see how much easier it is to arrange and distribute stuff.”(Nemi). Flexbox gets away from the traditional standards of CSS and creates a new and exciting way to help to develop websites, once you learn the mechanisms of Flexbox, the traditional standards of CSS can seem outdated. 
</p>
</section>

<!-- END LEFT COL -->
     
<!-- START RIGHT COL -->
 <aside>
         <h3>Citations</h3>
           <dl>
             <dt>“Flexbox”<a href="https://developer.mozilla.org/en-US/docs/Learn/CSS/CSS_layout/Flexbox " target = "_blank"> FLEXBOX.COM </a> </dt>
             <dd>FLEXBOX</dd>
         
         </dl>
         <dl>
             <dt> “Understanding Basic Concepts of CSS Flexbox”<a href="https://codeburst.io/understanding-basic-concepts-of-css-flexbox-ffa657dc39c1" target = "_blank"> FLEXBOX.COM </a></dt>
             <dd>FLEXBOX </dd>
         </dl>
</aside>
<!-- END RIGHT COL -->
       
 <footer>
      <p><small>&copy; 2018- 2019 by <a href="clientform.php">Contact Nicole Finamore</a>, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer" target="_blank">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank">Valid CSS</a></small></p>
    </footer>  