<?php include 'includes/config.php';?>
<?php include 'includes/header.php';?>
<!-- START LEFT COL--> 
 <section>
 <h2 class="pageID">Client questions</h2>
     
</section>
<!-- END LEFT COL -->
     
<!-- START RIGHT COL -->
 <aside>
 <h3>Client Resources</h3>
 <p>List some of your favorite sites that help clients</p>
 </aside>
<!-- END RIGHT COL -->
       
<?php include 'includes/footer.php'?>
  