<?php include 'includes/header.php';?>
<section>
<div class='embed-container'><iframe src='https://www.youtube.com/embed/COL_qPL5xsg' frameborder='0' allowfullscreen>
    </iframe>
</div>
</section>
<!  -- End Left Column -->

<! --Start Right Column -->
<aside>
<h3>SEO Resources</h3>
<ul>
    <li><a href="#" target="_blank">Resource Link 1</a></li>
    <li><a href="#" target="_blank">Resource Link 2</a></li>
    <li><a href="#" target="_blank">Resource Link 3</a></li>
    
    
    
</ul>
</aside>
<! --End Right Column -->



<?php include 'includes/footer.php';?>