

<!DOCTYPE html>
<html lang="en">
 <head>
  <title>Nicole's BIG Page!</title>
  <meta name="robots" content="noindex,nofollow" />
  <meta name="viewport" content="width=device-width" />
  <meta charset="utf-8" />
    <!--script src="https://use.fontawesome.com/6a71565c22.js"></script-->
     <!--from menumaker zip file-->
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="https://s3.amazonaws.com/menumaker/menumaker.min.js" type="text/javascript"></script>
    <script src="js/script.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="css/styles.css" />
     <!--from menumaker zip file-->
  <link rel="stylesheet" href="css/big.css" />
  <link rel="stylesheet" href="css/nav.css" />
  <link rel="stylesheet" href="css/form.css" />
 </head>
 
<body>   
<!--START WRAPPER-->
<div class="wrapper">
<header>
  <h1><a href="index.php"><i class="logo fa fa-home"></i>NICOLE FINAMORE'S WEB EXAMPLES/RESEARCH ARTICLES</a></h1>
  <nav id="cssmenu">
  <ul>
     <li><a href="../index.php"><span><i class="fa fa-fw fa-bank"></i> WEB120 Portal</span></a></li>
     <li><a href="index.php"><span><i class="fa fa-fw fa-home"></i> Home</span></a></li>
     <li><a href="flexbox.php"><span>Flexbox</span></a></li>
     <li><a href="galleries.php"><span>Galleries</span></a></li>
     <li><a href="#"><span><i class="fa fa-fw fa-chevron-down"></i> Google</span></a>
        <ul>
           <li><a href="map.php"><span>Map</span></a></li>
           <li><a href="calendar.php"><span>Calendar</span></a></li>
           <li><a href="youtube.php"><span>YouTube</span></a></li>
        </ul>
     </li>
     <li><a href="shoppingcarts.php"><span>Shopping Carts</span></a></li>
     <li><a href="siteapp.php"><span>Site vs App</span></a></li>
     <li><a href="webcam.php"><span>Web Cam</span></a></li>
  </ul>
</nav>
</header><!-- START LEFT COL--> 
    <section>
    <h2>SHOPPING CARTS</h2>
    
 <p>Ecommerce is such a big business that some businesses or companies sell all of their goods or services entirely online without the use of a traditional brick and mortar retail store. Selling services or goods online have become the new way to sell and target a generation of internet users who have never grown up without a smartphone, so for them to purchase their goods online is very normal. This business has grown to the point where there are now apps available known as “Shopping Carts” that businesses use to help sell their goods across the internet. If designing a website for a client it is best to look at the features of these apps to see which would go good with your client’s needs. Websites can be created as a hobby or can be seen as a way to maximize profits for the serial entrepreneur, which can be seen in this article from Evans, “If you’re like most you fall into one of two categories. Either you started your website for fun and are now looking for a way to turn it into an income generator, or you started it with a business goal in mind but need a way to maximize your revenue.”(Evans)</p>
 <p>Although it may be easy to get started in monetizing your website that is just the start. You still have to develop clever marketing strategies to keep your website making money, as can be seen in this article by Shopify, “After adopting one of the above techniques, you’ll need to work on honing your conversion strategy, delivering value, growing your audience, and more. It’s no walk in the park, but the rewards can be massive.”(Ismail) Shopify is a great website that allows businesses to sell the goods online through a hosted site, which can be seen in these words from Merchant Maverick, “Shopify is a ecommerce platform specializing in ease of use. Reasonably priced with a solid feature set, and round the clock customer service, Shopify is one of the best shopping carts on the market today, as many independent Shopify reviewers can attest. There are numerous Shopping Carts available, but the one you choose should be the one that best suits your website and the ease of use. Those who aren’t computer savvy or know how to code should look for the one that they can navigate with ease, and Shopify is top rated amongst its users and developers.</p>
<section>
<!-- END LEFT COL -->
     
<!-- START RIGHT COL -->
 <aside>
         <h2>Citations</h2>
           <dl>
             <dt>11 Ways To Monetize Your Website<a href="https://www.shopify.com/content/11-ways-to-monetize-your-website" target = "_blank">SHOPIFYCOM.COM</a>
            </dt>
             <dd>SHOPIFY</dd>
         
         </dl>
         <dl>
             <dt>"Proven Ways To Monetize A Website To Make Money"<a href="https://startbloggingonline.com/how-to-monetize-website/ " target = "_blank">STARTBLOGGINGONLINE.COM</a>
             </dt>
             <dd>STARTBLOGGINGONLINE</dd>
         </dl>
         <dl>
             <dt>"Shopify Review"<a href="https://www.merchantmaverick.com/reviews/shopify-review/" target = "_blank">MERCHANTMAVERICK.COM</a>
             </dt>
             <dd>MERCHANTMAVERICK</dd>
         </dl>
</aside>
<!-- END RIGHT COL -->
       
 <footer>
      <p><small>&copy; 2018- 2019 by <a href="clientform.php">Contact Nicole Finamore</a>, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer" target="_blank">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank">Valid CSS</a></small></p>
    </footer>  