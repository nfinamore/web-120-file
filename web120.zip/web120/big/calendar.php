<?php include 'includes/header.php';?>
<section>
<div class='embed-container month-view'>
    <iframe src='https://calendar.google.com/calendar/embed?src=4b3rpqmm3p19qa7i809d4n1tus%40group.calendar.google.com&ctz=America%2FLos_Angeles' style='border-width: 0' scrolling='no'>
    </iframe>
</div>
</section>
<!  -- End Left Column -->

<! --Start Right Column -->
<aside>
<h3>BDAY</h3>
<p>NICOLE'S BDAY IN THA WEST SIDE!!!!</p>
</aside>
<! --End Right Column -->



<?php include 'includes/footer.php';?>