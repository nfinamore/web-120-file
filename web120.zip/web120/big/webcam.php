<?php include 'includes/header.php';?>
<section>
<div class='embed-container'>
    <iframe src='https://www.youtube.com/embed/21X5lGlDOfg' allowfullscreen>
    </iframe>
</div>
</section>
<!  -- End Left Column -->

<! --Start Right Column -->
<aside>
<h3>West Seattle DOT Traffic Web Cam</h3>
<div class='embed-container'>
    <iframe src='http://www.nicolecodes.net/web120/big/webcam.html' style='border:0'>
    </iframe>
    </div>
</aside>
<! --End Right Column -->



<?php include 'includes/footer.php';?>