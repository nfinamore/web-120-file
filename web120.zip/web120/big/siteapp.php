

<!DOCTYPE html>
<html lang="en">
 <head>
  <title>Nicole's BIG Page!</title>
  <meta name="robots" content="noindex,nofollow" />
  <meta name="viewport" content="width=device-width" />
  <meta charset="utf-8" />
    <!--script src="https://use.fontawesome.com/6a71565c22.js"></script-->
     <!--from menumaker zip file-->
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <script src="https://s3.amazonaws.com/menumaker/menumaker.min.js" type="text/javascript"></script>
    <script src="js/script.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="css/styles.css" />
     <!--from menumaker zip file-->
  <link rel="stylesheet" href="css/big.css" />
  <link rel="stylesheet" href="css/nav.css" />
  <link rel="stylesheet" href="css/form.css" />
 </head>
 
<body>   
<!--START WRAPPER-->
<div class="wrapper">
<header>
  <h1><a href="index.php"><i class="logo fa fa-home"></i>NICOLE FINAMORE'S WEB EXAMPLES/RESEARCH ARTICLES</a></h1>
  <nav id="cssmenu">
  <ul>
     <li><a href="../index.php"><span><i class="fa fa-fw fa-bank"></i> WEB120 Portal</span></a></li>
     <li><a href="index.php"><span><i class="fa fa-fw fa-home"></i> Home</span></a></li>
     <li><a href="flexbox.php"><span>Flexbox</span></a></li>
     <li><a href="galleries.php"><span>Galleries</span></a></li>
     <li><a href="#"><span><i class="fa fa-fw fa-chevron-down"></i> Google</span></a>
        <ul>
           <li><a href="map.php"><span>Map</span></a></li>
           <li><a href="calendar.php"><span>Calendar</span></a></li>
           <li><a href="youtube.php"><span>YouTube</span></a></li>
        </ul>
     </li>
     <li><a href="shoppingcarts.php"><span>Shopping Carts</span></a></li>
     <li><a href="siteapp.php"><span>Site vs App</span></a></li>
     <li><a href="webcam.php"><span>Web Cam</span></a></li>
  </ul>
</nav>
</header><!-- START LEFT COL--> 
    <section>
    <h2>SITE VS APP</h2>
 <p>In today’s day and age the need for a website can be crucial for those who own businesses that offer services or who are trying to sell something. Websites are so commonplace that if you own a business it would be almost unheard of if you did not have a website for your business. Websites allow consumers to visit your site, find out about your products or the services you provide, and if possible maybe even buy your product. A website can be the turning point for customer loyalty, whether the website is simple or elaborate, the customer needs a place to turn to in order to engage in what you are offering or selling. With websites being the main landing point for a consumer to find information, the new wave of mobile apps has come into play and allows businesses options on which way they would like their information relayed. Mobile apps offer businesses a different form of technology that is slowly growing, as can be seen in this article by Thinkmobiles, “One, especially businessmen, should always look into the future and the future is in mobile technologies and their development.”(Thinkmobile)</p>
 <p>Mobile apps offer another way for consumers to find what they are looking for via a simple download on their mobile phones. Mobile apps are becoming so commonplace that some mobile apps are already downloaded on your phone when you purchase any version of an iphone. The differences between responsive vs mobile seems to rely on cost, which version is easier to make and which version is easier to navigate. Responsive design such as a website is easier to make and is more affordable, through CSS rules it can fit any device. A question you may ask yourself is that if a website can shrink itself from a desktop to a mobile device why would you need the mobile app at all? Because the increase of those using phones is increasing, as can be found in this article in Think Mobiles, “...did you know that the quantity of mobile users is going to increase worldwide from 4.01 billion in 2013 to 5.07 billion in 2019?” </p>
<p>When deciding between Responsive website and Mobile app, instead of trying to figure out which one is better, you need to decide what your business is and who is your audience,  as can seen in this quote found in an article on Smashstack, “Perhaps a better question would be, what is best for you?” When choosing between Responsive and Mobile app, choose the one which makes sense to the business. Which version best compliments the business. </p>
</section>
<!-- END LEFT COL -->
     
<!-- START RIGHT COL -->
 <aside>
         <h3>Citations</h3>
           <dl>
             <dt>"Responsive Website vs Mobile App Comparison"<a href="https://thinkmobiles.com/blog/responsive-website-vs-mobile-app/" target = "_blank">THINKMOBILES.COM</a>
            </dt>
             <dd>THINKMOBILES</dd>
         
         </dl>
         <dl>
             <dt>"The Pros and Cons of Mobile Apps Versus Responsive Web Design"<a href="https://www.smashstack.com/articles/the-pros-and-cons-of-mobile-apps-vs-responsive-web-design/" target = "_blank">SMASHSTACK.COM</a>
             </dt>
             <dd>SMASHSTACK</dd>
         </dl>
</aside>
<!-- END RIGHT COL -->
       
 <footer>
      <p><small>&copy; 2018- 2019 by <a href="clientform.php">Contact Nicole Finamore</a>, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer" target="_blank">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank">Valid CSS</a></small></p>
    </footer>  