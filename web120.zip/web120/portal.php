
<!DOCTYPE html>
<html lang="en">
 <head>
  <title>Nicole Finamore's WEB120 Portal Website</title>
  <meta name="robots" content="noindex,nofollow" />
  <meta name="viewport" content="width=device-width" />
  <meta charset="utf-8" />
  <link rel="stylesheet" href="css/portal.css" />
  <link rel="stylesheet" href="css/nav.css" />
  <link rel="stylesheet" href="css/form.css" />
  <link rel="stylesheet" href="css/big.css" />
</head>
 <body>
     <header>
     <h1>Nicole Finamore's WEB120 Website</h1>
     <nav class="topnav" id="myTopnav">
       <a href="index.html" class="active">Welcome</a>
       <a href="aia.html">AIA</a>
       <a href="big/index.html">BIG</a>
       <a href="https://www.linkedin.com/learning/" target="_blank">LinkedIn Learning</a>
       <a href="flowchart.html">Flowchart</a>
       <a href="fp/index.html">Final Project</a>
       <a href="contact.php">Contact Nicole</a>
       <a href="javascript:void(0);" class="icon" onclick="myFunction()">&#9776;</a>
      </nav>
      </header>
     <!--START LEFT COL -->
     <section>
 <h2 class="pageID">Welcome</h2>
   <!-- MAKE SURE YOU GET YOUR (3) IMAGES SAVED INTO YOUR IMAGES FOLDER -->
 <img src="images/desktop.jpg" class="desktop" alt="orca" />
 <img src="images/phone.jpg" class="phone" alt="orca" />
 <p>I grew up in Seattle and love the Pacific Northwest</p>
 <p>I am a 4th generation Seattleite and my great grandmother owned a Scandinavian restaurant on Broadway in the late 1800's.</p>
 <p>I went to camp called Camp Colman that was located on the Puget Sound past Tacoma so I love all images of the Puget Sound.</p>
 <p>So far I have learned so much about coding and can't wait to learn more.</p>
</section>
<!-- END LEFT COL -->

<!-- START RIGHT COL -->
<aside>
 <h3>Right Column</h3>
 <img src="images/tablet.jpg" class="tablet" alt="pct" />
 <p>I love the Pacific Northwest it is forever my home.</p>
 <p>I have much respect for the Pacific Northwest and for the Natives that inhabited the place before the European arrived. I think Mt Rainer shoud be turned back to its original name Mt Tahoma.</p>
</aside>
<!-- END RIGHT COL -->
       
     <footer>
      <p><small>&copy; 2018 by <a href="contact.php">Contact Nicole Finamore</a>, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer" target="_blank">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank">Valid CSS</a></small></p>
    </footer>
  </div>
     
  <!-- Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon -->
     
  <script>
    function myFunction() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
            x.className += " responsive";
        } else {
            x.className = "topnav";
        }
    }   
 </script>
     
 </body>
</html>