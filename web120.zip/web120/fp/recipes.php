<?php include 'includes/config.php';?>
<?php include 'includes/header.php';?>
<!-- START LEFT COL--> 
 <section>
    <img src="images/recipesdesktop.jpg" class="desktop" alt="recipes" />
    <img src="images/recipestablet.jpg" class="tablet" alt="recipes" />
    <img src="images/recipesphone.jpg" class="phone" alt="recipes" />  
 <h2 class="pageID">Welcome To The Recipe Page</h2> 
     
 
</section>
<!-- END LEFT COL -->
     
<!-- START RIGHT COL -->
 <aside>
 <h3>Some of our favorite Recipes</h3>
 <p>Links</p>
 <p>Links</p>
 <p>Links</p>
 <p>Links</p>
 </aside>
<!-- END RIGHT COL -->
       
<?php include 'includes/footer.php'?>
  