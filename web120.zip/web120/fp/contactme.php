<?php include "includes/config.php";?>
<?php include "includes/header.php";?>
<!-- START LEFT COL--> 
 <section>
 <h2 class="pageID">Contact</h2>
     <?php
     include "includes/multiple.php";
     ?>
</section>
<!-- END LEFT COL -->
     
<!-- START RIGHT COL -->
 

<!-- END RIGHT COL -->
       
<?php include "includes/footer.php"?>
  