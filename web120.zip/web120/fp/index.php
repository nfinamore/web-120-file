<?php include "includes/config.php";?>
<?php include "includes/header.php";?>
<!-- START LEFT COL -->
<section>
 <h2 class="pageID">Welcome</h2>
   
<!-- MAKE SURE YOU GET YOUR (3) IMAGES SAVED INTO YOUR IMAGES FOLDER -->
 <img src="images/phone.jpg" class="phone" alt="plantbased" />
 <img src="images/desktop.jpg" class="desktop" alt="plantbased" />
 <p>Welcome To Vegans Dine, We Got You Covered!</p>
 <p></p>
 <p></p>
</section>
<!-- END LEFT COL -->

<!-- START RIGHT COL -->
<aside>
 <h3>Plant Based is Now!</h3>
 <p></p>
 <p></p>
</aside>
<!-- END RIGHT COL -->
 
<?php include "includes/footer.php";?>