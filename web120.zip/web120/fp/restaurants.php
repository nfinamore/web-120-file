<?php include 'includes/config.php';?>
<?php include 'includes/header.php';?>
<!-- START LEFT COL--> 
 <section>
 <h2 class="pageID">Favorite Restaurants</h2>
      <img src="images/restaurantsdesktop.jpg" class="desktop" alt="restaurant" />
     <img src="images/restaurantstablet.jpg" class="tablet" alt="restaurant" />
     <img src="images/restaurantsphone.jpg" class="phone" alt="restaurant" />
     <p>Click on a city and find your favorite Vegan restaurants</p>
    
</section>
<!-- END LEFT COL -->
     
<!-- START RIGHT COL -->
 <aside>
 <h3>CITIES</h3>
 <p>Seattle</p>
 <p>Portland</p>
 <p>SanFrancisco</p>
 <p>Los Angeles</p>
 </aside>
<!-- END RIGHT COL -->

<?php include 'includes/footer.php'?>
  