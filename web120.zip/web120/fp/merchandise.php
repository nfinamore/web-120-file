<?php include 'includes/config.php';?>
<?php include 'includes/header.php';?>
<!-- START LEFT COL--> 
 <section>
 <h2 class="pageID">Welcome To The Merchandise Page</h2> 
     <img src="images/merchandisedesktop.jpg" class="desktop" alt="merchandise" />  

</section>
<!-- END LEFT COL -->
     
<!-- START RIGHT COL -->
 <aside>
 <h3>Check out the Merchandise!</h3>
 <p>Links</p>
 <p>Links</p>
 <p>Links</p>
 <p>Links</p>
 </aside>
<!-- END RIGHT COL -->
       
<?php include 'includes/footer.php'?>
  