<?php
//config.php



//echo basename($_SERVER['PHP_SELF']);
define('THIS_PAGE' , basename($_SERVER['PHP_SELF']));

//helps prevent date errors
date_default_timezone_set('America/Los_Angeles');

//reCapthca credentials here 

$siteKey = "6LeRfpAUAAAAAAvra_-oPbdjGI-zQ-F3cLBxj0R1";
$secretKey = "6LeRfpAUAAAAAEgOxMKIhjDNalCGOftf8Zy-xyO-";

//echo THIS_PAGE; 

//die;

$title = THIS_PAGE; 

switch(THIS_PAGE){

    case 'index.php':
        $title = "Nicole\'s Vegan Page!";
       break; 

    case 'contactme.php':
        $title = "Nicole\'s Contact Page!";
     break; 
} 
//place URL & labels in the array here for navigation:
$nav1['index.php'] = "Welcome";
$nav1['restaurants.php'] = "Restaurants";
$nav1['recipes.php'] = "Recipes";
$nav1['merchandise.php'] = "Merchandise";
$nav1['contactme.php'] = "Contact Nicole";

/*
makeLinks function will create our dynamic nav when called.
Call like this:
echo makeLinks($nav1); #in which $nav1 is an associative array of links
*/

function makeLinks($linkArray)
{
    $myReturn = '';

    foreach($linkArray as $url => $text)
    {
        if($url == THIS_PAGE)
        {//selected page - add class reference
	    	$myReturn .= '<li><a class="selected" href="' . $url . '">' . $text . '</a></li>' . PHP_EOL;
    	}else{
	    	$myReturn .= '<li><a href="' . $url . '">' . $text . '</a></li>'  . PHP_EOL;
    	}    
    }
      
    return $myReturn;    
    
    
}





?>