<?php include 'includes/config.php';?>
<?php include 'includes/header.php';?>
<!-- START LEFT COL -->
<section class="wholepage">
 <h2 class="pageID">AIA Audience Issues and Concerns</h2>
 <table class="client"> 
	<tr> 
	 <th>Client Name</th> 
	 <td>Lisa Sawoya</td> 
	</tr> 
	<tr> 
	 <th>Business Name</th> 
	 <td>Vegans Dine</td> 
	</tr> 
	<tr> 
	 <th>New or Redesign? </th> 
	 <td>Brand new website</td> 
	</tr> 
	<tr> 
	 <th>Type of Website</th> 
	 <td>Food</td> 
	</tr> 
	<tr> 
	 <th>Client Goals</th> 
	 <td> To get an internet presence with new site </td> 
	</tr> 
	</table> 
<table class="audience"> 
	<tr> 
	 <th>Audience</th> 
	 <th>Issues, Concerns, Needs</th> 
	 <th>Approach</th> 
	</tr> 
	<tr> 
        <td><b>Vegans</b>These are families, couples, and single people who want to find out about Vegan food. They are age 21 and up, male, female, transgender and non-binary. Most have disposable income and have done some schooling ie Bachelor's or Certificate Training. They know how to search the internet and they have access to computer desktop/laptops, tablets, smartphones, and know how to look up Vacation Rental reviews. They have monitor resolutions of 1280x1040 and above, and their prefereed browser is Chrome with Google as their search engine.</td> 
	<td> 
	<ul><li>They want to find Vegan food in the cities that they live in.</li> 
	<li>They want to find Vegan Food in the cities they go visit.</li> 
	<li> They want to find recipes and suggestions on various ways to cook Vegan Food.</li> 
	</ul> 
	</td> 
	<td> 
	<ul><li>Easy navigational site, that is responsive on various devices, that shows Vegan Food photos</li> 
	<li>A site that shows restaurants.</li> 
	<li>A site that shows recipes.</li>
    </ul> 
	</td> 
	</tr> 
	<tr> 
        <td><b>People who are curious about the Vegan lifestyle</b>These curious Vegans are computer savvy, both PC and mac users, have access to internet via their desktops, laptops, mobile devices tablets. They have monitor resolutions of 1280x1040 and above, and their prefereed browser is Chrome with Google as their search engine.</td> 
	<td> 
	<ul><li>They want to become more educated about Vegan Food.</li>
	<li>They want to find out where they can purchase Vegan Food and items.</li> 
	<li>They want recipes on how to cook Vegan Food.</li> 
	</ul> 
	</td> 
	<td> 
	<ul><li>Easy navigational site, that is responsive on various devices, that shows photos of Vegan Food and items.</li> 
    <li>A site that shows restaurants featuring Vegan Food and their menus.</li>
    <li>They want easy recipes to learn</li>
    </ul>
	</tr> 
	<tr> 
        <td><b>Business Owners</b>Business Owners are computer savvy, both PC and mac users, have access to internet via their desktops, laptops, mobile devices tablets. They have monitor resolutions of 1280x1040 and above, and their prefereed browser is Chrome with Google as their search engine. </td> 
	<td>
    <ul><li>Business owners who want to offer discounts to Vegans via through a logo or through an add on the Vegan website.</li>
	<li>Looking for someone easy to work with, prefer someone local</li> 
    <li>They want to increase traffic to their businesses for more exposure and profits</li>
	</ul> 
    </td> 
	<td>
    <ul><li>Provide information about their restaurant/bar through logo or add on site.</li>
	<li>Provide links from Vegan site to business.</li> 
	<li>Offer discounts to Vegans, and local neighborhood discounts.</li>
    </ul>
    </td> 
	</tr> 
	</table> 
             
<?php include 'includes/footer.php';?>