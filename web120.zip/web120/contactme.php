<?php include 'includes/config.php';?>
<?php include 'includes/header.php';?>
<!-- START LEFT COL -->
<section>
 <h2 class="pageID">Contact Nicole</h2>
    <p class="clear-recaptcha"></p>
</section>
<!-- END LEFT COL -->
    
<!-- START RIGHT COL -->
<aside>
 <h3>Right Column</h3>
 <img src="images/tablet.jpg" class="tablet" alt="pct" />
 <p>I love the Pacific Northwest it is forever my home.</p>
 <p>I have much respect for the Pacific Northwest and for the Natives that inhabited the place before the Europeans arrived. I think Mt Rainer shoud be turned back to its original name Mt Tahoma.</p>
</aside>
<!-- END RIGHT COL -->
 
<?php include 'includes/footer.php';?>